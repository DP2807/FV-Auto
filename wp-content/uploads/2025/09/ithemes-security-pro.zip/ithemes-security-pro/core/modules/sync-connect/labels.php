<?php

return [
	'title' => __( 'Sync Connect', 'it-l10n-ithemes-security-pro' ),
];
