<?php

require_once( __DIR__ . '/class-itsec-sync-connect.php' );

$sync_connect = new ITSEC_Sync_Connect();
$sync_connect->run();
