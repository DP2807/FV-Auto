<?php

require_once( dirname( __FILE__ ) . '/class-itsec-dashboard.php' );

return 'ITSEC_Dashboard';
