<div class="itsec-sync-connect-fallback__or">
    <span><?php esc_html_e( 'Or', 'it-l10n-ithemes-security-pro' ) ?></span>
</div>
