<?php

return [
	'title' => __( 'WordPress Tweaks', 'it-l10n-ithemes-security-pro' ),
];
