<?php

return [
	'title' => __( 'Have I Been Pwned', 'it-l10n-ithemes-security-pro' ),
];
