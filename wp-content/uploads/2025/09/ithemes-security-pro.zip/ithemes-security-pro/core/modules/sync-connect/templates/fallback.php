<div class="itsec-sync-connect-fallback">
	<?php require( __DIR__ . '/or.php' ); ?>

    <p class="itsec-sync-connect-fallback__link-wrap itsec-sync-connect-fallback__link-wrap--type-wp">
        <a class="itsec-sync-connect-fallback__link"
            href="https://go.solidwp.com/solid-central--login-">
               <?php esc_html_e( 'Take me back to Central', 'it-l10n-ithemes-security-pro' ); ?>
        </a>
    </p>

</div>
