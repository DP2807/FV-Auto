<?php

require_once __DIR__ . '/class-itsec-wordpress-tweaks.php';

ITSEC_WordPress_Tweaks::deactivate();
