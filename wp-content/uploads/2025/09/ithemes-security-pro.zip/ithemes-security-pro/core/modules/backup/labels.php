<?php

return [
	'title' => __( 'Backup', 'it-l10n-ithemes-security-pro' ),
];
